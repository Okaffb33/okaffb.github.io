<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-param" content="_csrf">
    <meta name="csrf-token" content="9XgZc24jjPZGC4WU1PyzzHWCO94kh5xbu21t3vjVbWiyLSk-HFS1kHR76qCer-q-F-Rcj0Xv2A3LQD2Gu7sgDA==">
    <title>LBS VDN Management</title>
    <link href="/assets/996b6250/css/bootstrap.css" rel="stylesheet">
<link href="/css/site.css" rel="stylesheet"></head>
<body>

<div class="wrap">
    <nav id="w0" class="navbar-inverse navbar-fixed-top navbar"><div class="container"><div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#w0-collapse"><span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span></button><a class="navbar-brand" href="/index.php">VDN Manager</a></div><div id="w0-collapse" class="collapse navbar-collapse"><ul id="w1" class="navbar-nav navbar-right nav"><li class="active"><a href="/index.php?r=site%2Findex">Home</a></li>
<li><a href="/index.php?r=site%2Flogin">Login</a></li></ul></div></div></nav>
    <div class="container">
                        <div class="site-index">

    <div class="jumbotron">
        <h1>Welcome!</h1>

        <p class="lead">Site untuk Administrasi VDN di LBS.</p>
    </div>
</div>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <p class="pull-left">&copy; Polri 2024</p>
    </div>
</footer>

<script src="/assets/5fff842/jquery.js"></script>
<script src="/assets/2306a74e/yii.js"></script>
<script src="/assets/996b6250/js/bootstrap.js"></script></body>
</html>
